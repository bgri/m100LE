### m100le Changelog

- v0.l - added graceful exit prompt after social screen - Mar.31, 2022
- v0.k - added manual date flag and prompt to allow manual date entry workaround for units not Y2K capable - Mar.27, 2022
- v0.j - fix input characters and 'sorry' message bugs - Mar.23, 2022
- v0.i - first working version released - Mar.22, 2022

