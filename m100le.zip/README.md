# m100LE
 A Wordle-like game for the vintage Tandy (Radio Shack) Model 100
 
 <img width="794" alt="image" src="https://user-images.githubusercontent.com/14062627/157380662-b14b5225-cd50-479e-8fc5-f1fa1faf0162.png">

It's been too many years since I programmed in a version of Basic. Converting this popular word game to a vintage platform seemed like a great way to refresh the skills, so to speak.

m100le plays pretty much as Wordle does, with compromises made due to the lack of colour hints.

